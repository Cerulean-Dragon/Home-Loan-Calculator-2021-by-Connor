import tkinter 
from tkinter import*
from tkinter.ttk import*

def isfloat(num):
    try:
        float(num)
        return True
    except ValueError:
        return False
    
def check():
     if i == 1 or i == 2:
        if isfloat(textbox_input[i].get()) == True:
            if float(textbox_input[i].get()) > 100:
                textbox_input[i].set("Wrong")
        else:
            textbox_input[i].set("")

def calculate():
    for i in range(len(textbox_input)):
        if isfloat(textbox_input[i].get()) == False:
            textbox_input[i].set("Wrong")
        if i == 1 or i == 2:
            if isfloat(textbox_input[i].get()) == True:
                if float(textbox_input[i].get()) > 100:
                    textbox_input[i].set("Wrong")
            else:
                textbox_input[i].set("")
            
    loan_amount = int(loan_input.get())
    rate = float(rate_input.get())/100
    month = int(float(period_input.get())* 12)
    down_payment = float(dp_input.get())
    loan = loan_amount * (100 - down_payment)/100
    mr = rate/12
    monthly_payment = loan/(((((1+mr)**month)-1))/(mr*(1+mr)**month))
    monthly_interest = loan * mr
    for i in range(1, month + 1):
        monthly_interest = (loan * mr)
        principle = monthly_payment - monthly_interest
        balance = (loan - principle)
        if balance < 0:
            balance = 0.00
        loan = balance
        print(round(principle, 2), ',',round(monthly_interest,2), ',', round(balance, 2))
        
def clear():
    for i in range(len(textbox_input)):  #withdraw W2 - Results       #arrangement of code: 1.loading screen 2.results 3. withdraw loading screen
        textbox_input[i].set("")         #loading screen reappears when calculate button is clicked
    
W1 = Tk()
W1.title("Home Loan Calculator")
W1.geometry("700x600")
W1.maxsize(700,600)
W1_bg = PhotoImage(file=r"C:\Users\user\Pictures\BG6.png")
bg = Label(W1, image = W1_bg)
bg.place(x = 0, y = 0)

loan_input = StringVar()
l = Entry(W1, textvariable = loan_input)
l.place(x = 40 , y = 193, width = 268)

dp_input = StringVar()
dp = Entry(W1, textvariable = dp_input)
dp.place(x = 40 , y = 285, width = 268)

rate_input = StringVar()
r = Entry(W1, textvariable = rate_input)
r.place(x = 40 , y = 375, width = 268)

period_input = StringVar()
mth = Entry(W1, textvariable = period_input)
mth.place(x = 40 , y = 466, width = 268)
               
textbox = [l, dp, r, mth]
textbox_input = [loan_input, dp_input, rate_input, period_input]

btn = Button(W1, text = "Calculate", command = calculate)
btn.place(x = 300, y = 300)

btn2 = Button(W1, text = "Clear", command = clear)
btn2.place(x = 300, y = 400)
