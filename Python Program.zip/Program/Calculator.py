# Path: OneDrive\Coding\Sublime\Home Loan Calculator by YanZheChan\Program
# Execution: python Calculator.py

import tkinter as tk
from tkinter import *
from tkinter.ttk import*
from tkinter import ttk, filedialog
import pandas as pd

# check if the data is a float
def isfloat(num):
    try:
        float(num)
        return True
    except ValueError:
        return False

# clear list data
def clear_list():
    error.clear()
    colour_change.clear()
    period_list.clear()
    principle_list.clear()
    interest_list.clear()
    balance_list.clear()
    output.clear()

# clear mistakes
def clear():
    error_btn.config(state=DISABLED)
    calc_btn.config(state=NORMAL)
    for i in range(len(error)):
        error[i].set("")         
        colour_change[i].config(foreground="black")
    clear_list()

# reset input data
def reset():
    calc_btn.config(state=NORMAL)
    for i in range(len(textbox)):
        textbox[i].config(foreground="black")
        textbox_input[i].set("")
    clear_list()

# calculate the data
def calculate():
    global lm, dwnp, mir, lprd
    lm.destroy()
    dwnp.destroy()
    mir.destroy()
    lprd.destroy()
    calc_btn.config(state=DISABLED)
    reset_btn.config(state=NORMAL)
    clear_list()

    # error handling
    for i in range(len(textbox_input)):
        if isfloat(textbox_input[i].get()) == False:
            error.append(textbox_input[i])
            colour_change.append(textbox[i])
            textbox_input[i].set("Please enter only numbers.")
            textbox[i].config(foreground="red")
        else:
            if i == 1 or i == 2:
                if isfloat(textbox_input[i].get()) == True:
                    if float(textbox_input[i].get()) > 100 or float(textbox_input[i].get()) < 0:
                        error.append(textbox_input[i])
                        colour_change.append(textbox[i])
                        textbox_input[i].set("Enter a value within 0 to 100.")
                        textbox[i].config(foreground="red")
            if i == 3:
                if isfloat(textbox_input[i].get()) == True:
                    if float(textbox_input[i].get()) > 100 or float(textbox_input[i].get()) <= 0:
                        error.append(textbox_input[i])
                        colour_change.append(textbox[i])
                        textbox_input[i].set("Enter a value within 1 to 100.")
                        textbox[i].config(foreground="red")
        
    if len(error) > 0:
        error_btn.config(state=NORMAL)
    if len(error) == 0:
        error_btn.config(state=DISABLED)
    
    # calculations            
    loan_amount = float(loan_input.get())
    rate = float(rate_input.get())/100
    month = int(float(period_input.get())* 12)
    down_payment = float(dp_input.get())
    loan = loan_amount * (100 - down_payment)/100
    mr = rate/12
    monthly_payment = loan/(((((1+mr)**month)-1))/(mr*(1+mr)**month))
    monthly_interest = loan * mr
    for i in range(1, month + 1):
        monthly_interest = (loan * mr)
        principle = monthly_payment - monthly_interest
        balance = (loan - principle)
        period_list.append(i)
        principle_list.append(format(principle,".2f"))
        interest_list.append(monthly_interest)
        balance_list.append(format(balance,".2f"))
        if balance < 0:
            balance = 0.00
            balance_list.remove(balance_list[len(balance_list) - 1])
            balance_list.append(format(0,".2f"))
        loan = balance
    output.append(format(monthly_payment,".2f"))
    output.append(sum(interest_list))
    output.append(format((loan_amount + sum(interest_list)),".2f"))

    # Labels on Results page
    lm = Label(rp_frame, text=format(loan_amount, ".2f"))
    lm.configure(font=('Times New Roman',12,'bold'), foreground="black", background="white")
    lm.place(x=76, y=143)
    dwnp = Label(rp_frame, text=format((loan_amount * down_payment/100),".2f")) 
    dwnp.configure(font=('Times New Roman',12,'bold'), foreground="black", background="white")
    dwnp.place(x=366, y =143)
    mir = Label(rp_frame, text=format((float(rate_input.get())/12),".2f"))
    mir.configure(font=('Times New Roman',12,'bold'), foreground="black", background="white")
    mir.place(x=76, y=218)
    lprd = Label(rp_frame, text=month)
    lprd.configure(font=('Times New Roman',12,'bold'), foreground="black", background="white")
    lprd.place(x=366, y=218)

    # Label on Results page - Clear Treeview
    for i in tree.get_children():
        tree.delete(i)
    for i in tree2.get_children():
        tree2.delete(i) 
        
    results_pg()

# navigate to Calculate page
def cal_pg():
    rp_frame.place_forget()
    mainframe.place_forget()
    calc_frame.place(x=0, y=0)
    for i in tree.get_children():
        tree.delete(i)

# navigate to Results page
def results_pg():
    mainframe.place_forget()
    calc_frame.place_forget()
    rp_frame.place(x=0, y=0, width=700, height=600)
    if len(principle_list) > 0:
        tree.insert(parent='', index='end', iid=3, text="parent", values=(output[0], format(output[1],".2f"), output[2]))
    calc_btn.config(state=NORMAL)

# navigate to Analysis page
def details():
    calc_frame.place_forget()
    rp_frame.place_forget()
    mainframe.place(x=0, y=0, width=700, height=600)
    calc_btn.config(state=NORMAL)
    mainframe.place(x=0, y=0, width=700, height=600)
    for i in range(len(period_list)):
        tree2.insert(parent = '', index = 'end', iid = i, text = "parent", values = (period_list[i], principle_list[i], format(interest_list[i],".2f"), balance_list[i]))
    if len(error) == 0 and len(principle_list) > 0:
        exportbtn.configure(state=NORMAL)

# Export to Excel
def download():
    interest_list2 = []
    for i in range(len(interest_list)):
        interest_list2.append(format(interest_list[i], ".2f"))
    b = float(loan_input.get())
    period_list.append("")
    period_list.append("Monthly payment (RM)")
    period_list.append("Total interest (RM)")
    period_list.append("Total payment (RM)")
    principle_list.append("")
    principle_list.append(output[0])
    principle_list.append(output[1])
    principle_list.append(output[2])
    interest_list2.append("")
    interest_list2.append("")
    interest_list2.append("")
    interest_list2.append("")
    balance_list.append("")
    balance_list.append("")
    balance_list.append("")
    balance_list.append("")
    
    # Pandas dataframe 
    df = pd.DataFrame({
        "Period (Month)": period_list,
        "Principle (RM)": principle_list,
        "Interest (RM)": interest_list2,
        "Balance (RM)": balance_list
    })

    filename = filedialog.asksaveasfilename()
    df.to_excel(filename + ".xlsx", index=False)

# Help page
def helpb():
    W2 = Tk()
    W2.title("Info")
    W2.maxsize(650,200)
    W2.minsize(650,200)

    helplbl = Text(W2, width=400, height=150)
    helplbl.pack()
    
    info = """
    Access this link for help:

    ------------------------------------------------------------------------
    |https://github.com/Cerulean-Dragon/Home-Loan-Calculator-2021---Connor |
    ------------------------------------------------------------------------

    It is a GitHub link which brings you to the page where 
    instructions to operate this application are held.

    """

    helplbl.insert(tk.END, info)

# main program
W1 = Tk()
W1.title("Home Loan Calculator")
W1.maxsize(700,600)
W1.minsize(700,600)
W1_menus = Menu(W1)
W1.config(menu=W1_menus)

# Menus
W1_menus.add_command(label="Calculator", command=cal_pg)
W1_menus.add_command(label="Results", command=results_pg)
W1_menus.add_command(label="Analysis", command=details)

# Menus
# Calculator page
calc_frame = Frame(W1, width=700, height=600)
calc_bg = PhotoImage(file="calbg.png")
calc_frame.place(x=0, y=0)
lbl = Label(calc_frame, image=calc_bg)
lbl.place(x=0, y=0)

# Entries on Calculator page
# loan amount
loan_input = StringVar()
l = Entry(calc_frame, textvariable=loan_input)
l.place(x=40 , y=193, width=268)
#down payment
dp_input = StringVar()
dp = Entry(calc_frame, textvariable=dp_input)
dp.place(x=40 , y=285, width=268)
#interest rate
rate_input = StringVar()
r = Entry(calc_frame, textvariable = rate_input)
r.place(x = 40 , y = 375, width = 268)
# loan period
period_input = StringVar()
mth = Entry(calc_frame, textvariable = period_input)
mth.place(x = 40 , y = 466, width = 268)

# Buttons on Calculator page
btn_img = PhotoImage(file="tru_or.png")
style = ttk.Style()
style.configure("cancelborder.TLabel", background="#E7B88D", borderwidth= 0)
calc_btn = Button(calc_frame, image=btn_img, style="cancelborder.TLabel", command=calculate)
calc_btn.place(x=450, y=360, width=130, height=130) # x = 480
# Clear errors
error_btn = Button(calc_frame, text="Clear Error(s)", command=clear)
error_btn.place(x=28, y = 540, width=140, height=50)
error_btn.config(state = DISABLED)
# Reset input
reset_btn = Button(calc_frame, text="Reset", command=reset)
reset_btn.place(x=184, y=540, width=140, height=50)
reset_btn.config(state=DISABLED)
helpbg = PhotoImage(file="helpbtnimg.png")
style = ttk.Style()
style.configure("help.TLabel", background="#74947C", borderwidth=0)
helpbtn = Button(calc_frame, image=helpbg, style="help.TLabel", command=helpb)
helpbtn.place(x=600, y=60, width=32, height=31)

# Results page
rp_frame = Frame(W1)
rp_frame.place(x=0, y=0, width=700, height=600)
rp_frame.place_forget()
rpbg = PhotoImage(file="w2bg13.png")
rpg = Label(rp_frame, image=rpbg)
rpg.place(x=0, y=0)

# Treeview on Results page
tree = ttk.Treeview(rp_frame)
tree["columns"] = ("Monthly Payment (RM)", "Total Interest (RM)", "Total Payment (RM)")
tree.place(x=75, y=270, height=80)

# columns
tree.column("#0", width=0, stretch=0)
tree.column("Monthly Payment (RM)", width=190, minwidth=180)
tree.column("Total Interest (RM)", width=180, minwidth=180)
tree.column("Total Payment (RM)", width=180, minwidth=180)

# headings
tree.heading("#0")
tree.heading("Monthly Payment (RM)", text="Monthly Payment (RM)", anchor=CENTER)
tree.heading("Total Interest (RM)", text="Total Interest (RM)", anchor=CENTER)
tree.heading("Total Payment (RM)", text="Total Payment (Loan + Interest)", anchor=CENTER)

#Labels on Results page
lm = Label(rp_frame, text="")
lm.configure(font=('Times New Roman',12,'bold'), foreground="black", background="white")
lm.place(x=76, y=143)
dwnp = Label(rp_frame, text="") 
dwnp.configure(font=('Times New Roman',12,'bold'), foreground="black", background="white")
dwnp.place(x=366, y =143)
mir = Label(rp_frame, text="")
mir.configure(font=('Times New Roman',12,'bold'), foreground="black", background="white")
mir.place(x=76, y=218)
lprd = Label(rp_frame, text="")
lprd.configure(font=('Times New Roman',12,'bold'), foreground="black", background="white")
lprd.place(x=366, y=218)

# Analysis page
# Treeview Frame
mainframe = Frame(W1)
mainframe.place(x=0, y=0, width=700, height=600)
mainframe.place_forget()
tree_frame = Frame(mainframe)
tree_frame.place(x=50, y=50, width=600, height=450)

# Scrollbar
tree_scroll = Scrollbar(tree_frame)
tree_scroll.pack(side=RIGHT, fill=Y)

# Treeview
tree2 = ttk.Treeview(tree_frame, yscrollcommand=tree_scroll.set)
tree2["columns"] = ("Period (month)", "Principle", "Interest", "Balance")
tree2.config(height=300)
tree2.pack()
# columns
tree2.column("#0", width=0, stretch=0)
tree2.column("Period (month)", width=150, minwidth=150)
tree2.column("Principle", width = 150, minwidth=150)
tree2.column("Interest", width=150, minwidth=150)
tree2.column("Balance", width=150, minwidth=150)
# headings
tree2.heading("#0")
tree2.heading("Period (month)", text="Period (month)", anchor=CENTER)
tree2.heading("Principle", text="Principle (RM)", anchor=CENTER)
tree2.heading("Interest", text="Interest (RM)", anchor=CENTER)
tree2.heading("Balance", text="Balance (RM)", anchor=CENTER)
# Configure Scrollbar
tree_scroll.config(command=tree2.yview)

# Export to Excel buttton
ebtnbg = PhotoImage(file="expbtnimg.png")
style = ttk.Style()
style.configure("expbtn.TLabel", background="#FFFFFF", borderwidth= 0, relief=RAISED)
exportbtn = Button(mainframe, image=ebtnbg, style="expbtn.TLabel", command=download)
exportbtn.place(x=224, y=520, width=252, height=69)
exportbtn.config(state=DISABLED)

# lists
textbox = [l, dp, r, mth]
textbox_input = [loan_input, dp_input, rate_input, period_input]
error= []
colour_change = []
period_list = []
principle_list = []
interest_list = []
balance_list = []
output = []

W1.mainloop()
