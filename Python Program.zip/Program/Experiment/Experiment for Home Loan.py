'''
def isfloat(num):
    try:
        float(num)
        return True
    except ValueError:
        return False

a = ["a", 1]

for i in range(len(a)):
    print(isfloat(a[i])
'''

interest = []
money = 10000
r = 10
month = 120
down_payment = 10
loan = money * (100 - down_payment)/100

mr = r/100/12
monthly_payment = round(loan/(((((1+mr)**month)-1))/(mr*(1+mr)**month)),2)

monthly_interest = loan * mr
principle = monthly_payment - monthly_interest
balance = loan - principle

print("Loan:", loan)
print("Monthly payment ", monthly_payment)
print("Monthly interest:", monthly_interest)
print("Principle:", principle)
print("Balance:", balance)
print()

for i in range(48):
    monthly_interest = round((loan * mr), 2)
    interest.append(monthly_interest)
    principle = monthly_payment - monthly_interest
    balance = round((loan - principle), 2)
    monthly_payment2 = round((monthly_payment - monthly_interest), 2)
    loan = balance
    print(monthly_payment2, ',',monthly_interest, ',', balance)
 

